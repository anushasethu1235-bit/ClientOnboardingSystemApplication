package com.productenrolment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientOnboardingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
